
# Jogo Quebra-Cabeça Interativo Infantil

## Funcionalidades:
- Upload de imagem ou foto da câmera
- Escolha de 20 ou 48 peças
- Sons de encaixe, vitória e música de fundo
- Cronômetro crescente
- Salvar imagem final como PNG
- Layout infantil, colorido, responsivo para celulares, tablets e PCs

## Como rodar localmente:
1. Instale as dependências:
   npm install
2. Rode o projeto:
   npm start

## Como publicar na web (ex.: Netlify, Vercel):
- Configure build como `npm run build`
- Configure publish directory como `build`
