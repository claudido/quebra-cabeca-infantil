// Código React do jogo aqui (gerado no ChatGPT)
